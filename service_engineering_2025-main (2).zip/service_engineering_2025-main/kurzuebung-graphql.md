GraphQL ist eine zustandslose Abfragesprache für webbasierte APIs, welche ursprünglich 2012 von Facebook veröffentlicht und 2015 als Open-Source-Projekt bereitgestellt wurde. Mittlerweile wurde die GraphQL Foundation unter dem Dach der gemeinnützigen Linux Foundation ausgegliedert. Das Projekt soll das Problem des "overfetchings" lösen, in dem feingranulare Ressourcenzugriffe ermöglicht und umgesetzt werden. GraphQL fungiert als Alternative oder Ergänzung zu REST- und HTML-basierten Web-Services. 

Dabei werden Abfragen durch ein GraphQL-Schema überprüft, sodass ein entsprechendes Datenobjekt konstruiert werden kann. Das Schema kann über sogenannte GraphQL-Types  in der GraphQL Schema Definition Language beschrieben werden. Dazu werden Typen mit Attributen definiert. Eine Besonderheit ist, dass zur Abfragezeit spezifiziert werden kann, welche Typen und Felder gefetcht werden sollen. Es gibt keine Endpunkte im klassischen Sinne, sondern nur Anfragen, die validiert und aufgelöst werden. Die Schemaspezifikation wird Entwicklern oft direkt vom GraphQL-Server bereitgestellt.

GraphQL unterstützt das Lesen, Schreiben und Abonnieren von Datenänderungen, um Echtzeit-Updates zu tracken.

GraphQL kann theoretisch mit jedem Backend/jeder Datenbank genutzt werden, die eine GraphQL-Engine hat.

**Schema**:
```
type Project { name: String tagline: String contributors: [User]}
```

**Abfrage**: 
```
{ project(name: "GraphQL") { tagline }}
```

**Antwort**:
```
{ "project": { "tagline": "A query language for APIs" }}
```

### Vorteile von GraphQL gegenüber REST:
1. **Flexible Datenabfragen**:
    - Der Client kann exakt spezifizieren, welche Felder benötigt werden. So wird Overfetching (zu viele Daten abrufen) und Underfetching (zu wenig Daten abrufen) vermieden.        
2. **Reduzierte Anzahl von Requests**:
    - Komplexe Abfragen können in einem einzigen Request abgefragt werden, während REST oft mehrere Requests benötigt (z.B. für Nested Resources).
3. **Bessere Versionierung und Evolution**:
    - Durch explizite Felddefinitionen und Typen im Schema können APIs einfacher weiterentwickelt werden, ohne bestehende Clients zu beeinträchtigen. Dadurch sinkt der Bedarf für explizite Versionierung der API.
4. **Selbstdokumentation und Typensicherheit**:
    - GraphQL APIs verfügen über eine eingebaute Dokumentation durch das Schema. Clients profitieren von automatisch generierter Dokumentation und Validierung.
5. **Effizienteres Caching auf Client-Seite**:
    - Durch definierte Queries können Clients effizientes lokales Caching betreiben (z.B. Apollo Client).
6. **Einheitlicher Endpunkt**:
    - GraphQL bietet in der Regel einen einzigen Endpunkt, was die API-Verwaltung vereinfacht.
### Nachteile von GraphQL gegenüber REST:
1. **Komplexität der Implementierung**:
    - Die Einrichtung und Wartung eines GraphQL-Servers ist oft komplexer als bei REST-APIs. Es entstehen höhere initiale Lern- und Entwicklungsaufwände.
2. **Schwierigkeiten beim serverseitigen Caching**:
    - Aufgrund der flexiblen Queries ist serverseitiges Caching (z.B. auf HTTP-Ebene) komplizierter umzusetzen als bei REST (wo URLs häufig eindeutig Ressourcen identifizieren).
3. **Performance-Risiken durch komplexe Queries**:
    - GraphQL erlaubt sehr flexible und tief verschachtelte Abfragen, was potenziell zu Performance-Problemen führen kann („[N+1 Problem](https://stackoverflow.com/questions/97197/what-is-the-n1-selects-problem-in-orm-object-relational-mapping)“), wenn die API nicht sorgfältig optimiert ist.
4. **Höherer Aufwand für Sicherheit**:
    - Der flexible Zugriff auf Daten erhöht Anforderungen an Autorisierung, Validierung und Sicherheit, um zu verhindern, dass Clients ungewünschte Daten abrufen können.
5. **Fehlende HTTP-Statussemantik**:
    - REST nutzt standardisierte HTTP-Statuscodes zur Fehlerbehandlung und für Caching-Strategien. Bei GraphQL ist dies weniger eindeutig, da Fehler auf Anwendungsebene zurückgegeben werden.

## Umsetzung für bestehende REST-APIs mit Apollo
Apollo ist eine open-source Entwicklungsumgebung für graph-basierte API-Orchestrierung, welche bei der Modellierung und Komposition von APIs als GraphQL-Schemas unterstützen soll. Die darunterliegenden APIs können auch REST-APIs sein, welche **in einem Graphen orchestriert werden.** Der "Graph" ist in diesem Framework das Zentrale Objekt und entspricht einer GraphQL-API, welche aus Verschiedenen subgraphs bestehen kann.

- das Datenschema kann auf API-Ebene statt auf Datenbank-Ebene modelliert werden
- Apollo bietet Connectors für die integration von REST-Services in den Graphen
- Apollo bietet Front-End-SDKs, um mit dem Graphen zu interagieren und IDE-Plugins
- Apollo bietet die GraphOS-API-Platform für das API-Management
- ein Router kann für Anfragen konfiguriert werden, um verschiedene Subgraphen zu orchestrieren
 
![[image-232.png|Referenzarchitektur Development ]]
![[image-233.png|Referenzarchitektur Production]]

## Umsetzung mithilfe von Cosmo
Cosmo ist eine kostenlose open-source Alternative für  Apollo und nennt sich eine "Lifecycle API Management platform tailored for Federated GraphQL"
Genau wie Apollo unterstützt das Framework auch die Implementierung eines Schemaverzeichnisses, Analytics, Metrics, und Routing. 
Ein zentraler Ansatz des Projekts ist die Föderierung von GraphQL-Schemas in kleinere Schemas, welche durch eigene Teams maintaint werden können. 

- `wgc` ist die Cosmo cli, mit welcher die Cosmo platform bedient werden kann, z.B. das veröffentlichen, validieren von Schemas; neue Projekte erstellen oder Zugriffsmanagement
- Die Control-Pane besteht aus der Platform API und der Node API. Die Platform API wird von `wgc` und *Studio* für das Platform management genutzt. Die Node API managed spezifische Instanzen der Graphen
- Der Router ist die Komponente, welche GraphQL-Aufrufe versteht und auf die Graphen routet
- Studio ist ein Web-Interface für die Cosmo-Platform für das Platform-Management und Kollaboration.

![[image-234.png|Architektur Cosmo ]]

## Schritte zur Entwicklung
1. **Anforderungsanalyse** 

2. **Schema-Design**
- Entwurf eines initialen GraphQL-Schemas (z. B. mit SDL – Schema Definition Language)
- Modellierung der Typen, Queries, Mutations und ggf. Subscriptions
- evtl.  in Subgraphen

3. **GraphQL-Server einrichten**
- **Apollo Server** oder **Cosmo Gateway** konfigurieren
- Resolver-Funktionen definieren, die bestehende REST-Endpunkte aufrufen
- Optional: REST-Datenquellen mit Apollo `RESTDataSource` abstrahieren
    
3. **Integration bestehender REST-Endpunkte**
- Erstellung von DataSources oder Resolvern zur Übersetzung von GraphQL-Anfragen in REST-Calls bei bestehenden APIs
- Fehlerbehandlung und Datenmapping
    
3. **Föderation (optional)**
- Aufteilen des Schemas in Subgraphen (nach Teams/Domänen)
- Veröffentlichung der Subgraphen ins Schema-Registry (z.B. via Apollo Studio oder Cosmo CLI)
    
5. **Testing und Validierung**
- Unit-Tests für Resolver
- Integrationstests gegen REST-Backends
- Schema-Validierung mit `wgc` (Cosmo) oder Apollo CLI    

7. **Deployment und Routing**
- Bereitstellung des Gateways/Routers (z.B. als Docker-Container oder Cloud-Service)
- Konfiguration von Caching, Authentifizierung und Ratenbegrenzung

8. **Monitoring, Sicherheit und Wartung**
- Logging und Metrics mit Apollo GraphOS oder Cosmo Studio
- Authentifizierung und Autorisierung auf Feldebene
- Dokumentation über introspektives Schema & Tools wie GraphQL Voyager, GraphiQL, Postman

---
## Quellen
[GraphQL | A query language for your API](https://graphql.org/)
[GraphQL – Wikipedia](https://de.wikipedia.org/wiki/GraphQL)
[GraphQL](https://github.com/graphql)
https://www.apollographql.com/
[WunderGraph Cosmo: The Open-Source GraphQL Federation Solution - WunderGraph](https://wundergraph.com/)
[wundergraph/cosmo: The open-source solution to building, maintaining, and collaborating on GraphQL Federation at Scale. The alternative to Apollo Studio and GraphOS.](https://github.com/wundergraph/cosmo?tab=readme-ov-file)
Vorlesungsfolien
