# Allgemeines
# Aufgaben und Ziele
# Vorgehen und Konzeption der Durchführung
# Ergebnisdarstellung
## Aufgabe 1
## Aufgabe 2
## Aufgabe 3
# Zusammenfassung
# Quellen