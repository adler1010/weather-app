# service_engineering_2025

TODO: 
- GraphQL: done
- Übung 2 (nur Dokumentieren)
- Übung x (alle)
- Übung y (M.Sc.)
