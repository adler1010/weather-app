# Allgemeines
# Aufgaben und Ziele
# Vorgehen und Konzeption der Durchführung
# Ergebnisdarstellung
## Aufgabe 1
- Entwickeln Sie auf der Basis von mind. 2 frei zu wählenden Web APIs eine mobile Applikation (kurz App). 
- Die Entwicklungsumgebung und die Art der zu implementierenden App (web, nativ, hybrid) kann frei gewählt werden, die konkrete Entscheidung ist in Bezug auf Vor- und Nachteile zu begründen.
- Recherchieren Sie nach Möglichkeiten einer cloud-basierten Entwicklung von mobilen Applikationen und gehen Sie dabei auf mind. 1 Beispiel ein.

TODO edit: Vorschlag von ChatGPT: https://pastebin.com/WDhaVXmR

## Aufgabe 2
Analysieren Sie die eingesetzten Services nach einem von Ihnen festgelegten Bewertungsmodell (Kriterien der Anforderung)
- FCM: Faktoren –Kriterien –Metriken
- GQM: Goal Question Metric
- ...
Welche Möglichkeiten sehen Sie für eine konstruktive und analytische QS von mobilen Apps?
- Besondere Herausforderungen beim Testen von Apps?
- Testansätze vs. Simulation entwickelter Apps?
- ...

| Faktor                   | Kriterium                  | Metrik                                                            |
|--------------------------|----------------------------|-------------------------------------------------------------------|
| **Genauigkeit**          | Temperatur-Fehler          | RMSE (Root Mean Squared Error) in °C gegenüber Referenzstationen  |
|                          | Niederschlags-Vorhersage   | Trefferquote (%) von Regen-/Schneevorhersagen                     |
| **Aktualität**           | Daten-Latenz               | Zeitspanne zwischen Messung und API-Bereitstellung (s)            |
|                          | Update-Frequenz            | Intervalldauer zwischen Daten-Pushes (min oder h)                |
| **Räumliche Abdeckung**  | Auflösungsgrad             | Rasterweite (z. B. 1 km × 1 km) oder Anzahl versorgter Regionen  |
|                          | Geodaten-Genauigkeit       | Maximale Abweichung in Koordinaten (m)                            |
| **Verfügbarkeit**        | Uptime                     | Prozentuale Verfügbarkeit pro Monat (z. B. ≥ 99,9 %)               |
|                          | Fehlerrate                 | Anteil 5xx-Antworten an Gesamt-Requests (%)                       |
| **Leistung**             | Antwortzeit                | Durchschnittliche API-Latenz (P50, P95 in ms)                     |
|                          | Durchsatz                  | Maximale Requests/s ohne Performance-Degradation                  |
| **Benutzerfreundlichkeit** | Dokumentations-Qualität   | Vollständigkeit (Endpunkte, Parameter, Beispiele) (Score 1–5)      |
|                          | SDK-Verfügbarkeit          | Anzahl unterstützter Sprachen/Plattformen                         |
| **Alerts & Historie**    | Unwetterwarnungen          | Latenz bis zur Benachrichtigung (s)                                |
|                          | Historische Daten          | Tiefe der Archivdaten (Anzahl Jahre)                              |
| **Kosten**               | Preis pro Request          | € Cent/Request                                                    |
|                          | Freikontingent             | Anzahl Gratis-Requests pro Monat                                  |

TODO edit: Vorschlag von ChatGPT: https://pastebin.com/14EqFnRL

## Aufgabe 3
In welcher Weise sollte die Architektur einer mobilen Applikationen festgelegt werden?
- Schichtentrennung (z.B. MVC-Ansatz)?
- Umgang mit unterschiedlichen NW-Anbindungen?
- Offline-Synchronisation?
- ...

TODO edit: Vorschlag von ChatGPT: https://pastebin.com/VeBhv9bS

In welcher Weise sind in mobilen Apps eingesetzte APIs zu verwalten (APIMiddleware/ API Gateway)?
- Funktionen eines API-Management?
- Erläuterung der Begriffe der Frontend API und Backend API?
- API-Publikation, Rechtevergabe und Monitoring?

TODO edit: Vorschlag von ChatGPT: https://pastebin.com/DxVGCVrG

# Zusammenfassung
# Quellen
